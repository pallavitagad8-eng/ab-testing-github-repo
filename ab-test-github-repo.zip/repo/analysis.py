"""Checkout A/B Test - Hypothesis Testing (Z-test, Chi-square, CI, effect size, power)."""
import pandas as pd, numpy as np, json
from scipy import stats
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = pd.read_csv("data/checkout_ab_test_v2.csv")
d["conv"] = (d.Converted == "Yes").astype(int)
alpha = 0.05

# Step 2: sample size & conversion rates
g = d.groupby("Variant").agg(n=("conv", "size"), x=("conv", "sum"), rev=("OrderValueINR", "sum"))
nA, xA = g.loc["A", ["n", "x"]]; nB, xB = g.loc["B", ["n", "x"]]
pA, pB = xA / nA, xB / nB
diff = pB - pA

# Step 3a: two-proportion Z-test (two-sided)
p_pool = (xA + xB) / (nA + nB)
se_pool = np.sqrt(p_pool * (1 - p_pool) * (1 / nA + 1 / nB))
z = diff / se_pool
p_z = 2 * (1 - stats.norm.cdf(abs(z)))
p_z_one = 1 - stats.norm.cdf(z)

# Step 3b: Chi-square test of independence
tab = np.array([[xA, nA - xA], [xB, nB - xB]])
chi2, p_chi, dof, _ = stats.chi2_contingency(tab, correction=False)
chi2c, p_chic, _, _ = stats.chi2_contingency(tab, correction=True)

# Step 4: CI, effect sizes
se_unp = np.sqrt(pA * (1 - pA) / nA + pB * (1 - pB) / nB)
zc = stats.norm.ppf(1 - alpha / 2)
ci = (diff - zc * se_unp, diff + zc * se_unp)
rel_lift = diff / pA
rr = pB / pA
h = 2 * np.arcsin(np.sqrt(pB)) - 2 * np.arcsin(np.sqrt(pA))   # Cohen's h
phi = np.sqrt(chi2 / (nA + nB))
odds = (xB / (nB - xB)) / (xA / (nA - xA))
se_lo = np.sqrt(1/xA + 1/(nA-xA) + 1/xB + 1/(nB-xB))
or_ci = tuple(np.exp(np.log(odds) + s * zc * se_lo) for s in (-1, 1))
def wilson(x, n):
    p = x / n; c = zc**2
    m = (p + c/(2*n)) / (1 + c/n); w = zc*np.sqrt(p*(1-p)/n + c/(4*n*n)) / (1 + c/n)
    return m - w, m + w
ciA, ciB = wilson(xA, nA), wilson(xB, nB)

# Power / required sample size
def n_required(p1, p2, a=0.05, pw=0.8):
    za, zb = stats.norm.ppf(1 - a/2), stats.norm.ppf(pw)
    pb = (p1 + p2) / 2
    return ((za*np.sqrt(2*pb*(1-pb)) + zb*np.sqrt(p1*(1-p1)+p2*(1-p2)))**2) / (p1-p2)**2
n_req = n_required(pA, pB)
power = 1 - stats.norm.cdf(zc - abs(diff)/se_unp) + stats.norm.cdf(-zc - abs(diff)/se_unp)
mde_n = n_required(pA, pA*1.10)  # for 10% relative lift

# Secondary: revenue per visitor (Welch t-test), AOV
rA = d[d.Variant == "A"].OrderValueINR; rB = d[d.Variant == "B"].OrderValueINR
t, p_t = stats.ttest_ind(rB, rA, equal_var=False)
cA = d[(d.Variant=="A") & (d.conv==1)].OrderValueINR.mean(); cB = d[(d.Variant=="B") & (d.conv==1)].OrderValueINR.mean()

# Funnel
d["cs"] = (d.CheckoutStarted == "Yes").astype(int)
fun = d.groupby("Variant").agg(cs=("cs", "sum"), conv=("conv", "sum"), n=("cs", "size"))
fun["start_rate"] = fun.cs / fun.n; fun["cs_to_conv"] = fun.conv / fun.cs
# SRM check
p_srm = stats.chisquare([nA, nB]).pvalue

# Segments
seg = []
for col in ["Device", "TrafficSource"]:
    for k, s in d.groupby(col):
        a = s[s.Variant=="A"].conv; b = s[s.Variant=="B"].conv
        pp = s.conv.mean(); se = np.sqrt(pp*(1-pp)*(1/len(a)+1/len(b)))
        zz = (b.mean()-a.mean())/se
        seg.append([col, k, len(a), len(b), a.mean(), b.mean(), b.mean()-a.mean(), 2*(1-stats.norm.cdf(abs(zz)))])
seg = pd.DataFrame(seg, columns=["dim","segment","nA","nB","rateA","rateB","diff","p"])

R = dict(nA=int(nA), nB=int(nB), xA=int(xA), xB=int(xB), pA=pA, pB=pB, diff=diff, rel=rel_lift, rr=rr,
         p_pool=p_pool, se_pool=se_pool, z=z, p_z=p_z, p_z_one=p_z_one, chi2=chi2, p_chi=p_chi, chi2c=chi2c, p_chic=p_chic,
         ci=ci, ciA=ciA, ciB=ciB, h=h, phi=phi, odds=odds, or_ci=or_ci, n_req=n_req, power=power, mde_n=mde_n,
         t=t, p_t=p_t, rpvA=rA.mean(), rpvB=rB.mean(), aovA=cA, aovB=cB, revA=int(rA.sum()), revB=int(rB.sum()), p_srm=p_srm)
json.dump(R, open("results.json", "w"), indent=2, default=float)
fun.to_csv("funnel.csv"); seg.to_csv("segments.csv", index=False)

# Charts
c1, c2 = "#6b7280", "#4f46e5"
fig, ax = plt.subplots(figsize=(5, 3.6))
ax.bar(["A (Control)", "B (Variant)"], [pA*100, pB*100], color=[c1, c2], width=.5,
       yerr=[[ (pA-ciA[0])*100, (pB-ciB[0])*100], [(ciA[1]-pA)*100, (ciB[1]-pB)*100]], capsize=6)
for i, v in enumerate([pA, pB]): ax.text(i, v*100+2.6, f"{v*100:.2f}%", ha="center", fontweight="bold")
ax.set_ylabel("Conversion rate (%)"); ax.set_title("Conversion rate with 95% Wilson CI"); ax.set_ylim(0, 18)
plt.tight_layout(); plt.savefig("charts/conversion_rates.png", dpi=200); plt.close()

fig, ax = plt.subplots(figsize=(6, 3.6))
x = np.linspace(-0.06, 0.06, 500)
ax.plot(x*100, stats.norm.pdf(x, 0, se_pool), color=c1, label="Null: no difference")
ax.fill_between(x*100, stats.norm.pdf(x, 0, se_pool), where=np.abs(x) >= zc*se_pool, color="#ef4444", alpha=.3, label="Rejection region (α=0.05)")
ax.axvline(diff*100, color=c2, lw=2, label=f"Observed lift = {diff*100:.2f} pp")
ax.set_xlabel("Difference in conversion (pp)"); ax.set_yticks([]); ax.legend(fontsize=8); ax.set_title(f"Z-test: z = {z:.2f}, p = {p_z:.3f}")
plt.tight_layout(); plt.savefig("charts/z_test.png", dpi=200); plt.close()

fig, ax = plt.subplots(figsize=(6, 3.4))
ax.errorbar(diff*100, 0, xerr=[[diff*100-ci[0]*100], [ci[1]*100-diff*100]], fmt="o", color=c2, capsize=8, ms=9, lw=2)
ax.axvline(0, color="red", ls="--"); ax.set_yticks([]); ax.set_xlabel("Absolute lift B − A (pp)")
ax.set_title(f"95% CI for lift: [{ci[0]*100:.2f}, {ci[1]*100:.2f}] pp"); ax.set_xlim(-4, 8)
plt.tight_layout(); plt.savefig("charts/ci_lift.png", dpi=200); plt.close()

s = seg.copy(); lab = s.dim.str[0] + ": " + s.segment
fig, ax = plt.subplots(figsize=(6.5, 3.6)); xx = np.arange(len(s)); w = .38
ax.bar(xx-w/2, s.rateA*100, w, color=c1, label="A"); ax.bar(xx+w/2, s.rateB*100, w, color=c2, label="B")
ax.set_xticks(xx); ax.set_xticklabels(s.segment, rotation=30, fontsize=8); ax.set_ylabel("Conversion (%)"); ax.legend(); ax.set_title("Conversion by segment (exploratory)")
plt.tight_layout(); plt.savefig("charts/segments.png", dpi=200); plt.close()
print(json.dumps(R, indent=1, default=float)); print(fun); print(seg)
