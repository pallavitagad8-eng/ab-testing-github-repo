# Checkout A/B Test & Hypothesis Testing

Statistical analysis of a website checkout A/B test (Control A vs Variant B) using a two-sample Z-test and Chi-square test of independence, with confidence intervals, effect sizes, power analysis and an executive decision memo.

## Result
| | A (Control) | B (Variant) |
|---|---|---|
| Visitors | 600 | 600 |
| Conversions | 57 | 71 |
| Conversion rate | 9.50% | 11.83% |

- Lift: **+2.33 pp** (+24.6% relative), 95% CI [-1.16, 5.82] pp
- Z-test: z = 1.31, **p = 0.190**; Chi-square: χ² = 1.71, p = 0.190
- Cohen's h = 0.076 (very small); achieved power ~26%
- **Decision: Keep Control, extend test to ~2,746 visitors per variant.** The uplift is promising but not statistically significant.

## Hypotheses
- H0: p_B = p_A
- H1: p_B ≠ p_A (two-sided, α = 0.05)

## Repository structure
```
data/checkout_ab_test_v2.csv   dataset (1,200 visitors)
analysis.py                    all calculations + charts
make_report.py                 builds the PDF
AB_Test_Report.pdf             final report with decision memo
charts/                        generated figures
results.json, segments.csv, funnel.csv   outputs
```

## Run
```bash
pip install pandas numpy scipy matplotlib reportlab
python analysis.py
python make_report.py
```
