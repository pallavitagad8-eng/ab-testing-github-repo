import json, pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm

R = json.load(open("results.json")); seg = pd.read_csv("segments.csv"); fun = pd.read_csv("funnel.csv")
ss = getSampleStyleSheet()
B = ParagraphStyle("B", parent=ss["Normal"], fontSize=10, leading=14)
H1 = ParagraphStyle("H1", parent=ss["Heading1"], textColor=colors.HexColor("#3730a3"), fontSize=15)
H2 = ParagraphStyle("H2", parent=ss["Heading2"], textColor=colors.HexColor("#4f46e5"), fontSize=12)
T = ParagraphStyle("T", parent=ss["Title"], fontSize=22, textColor=colors.HexColor("#3730a3"))
def tbl(rows, widths=None, head=True):
    t = Table(rows, colWidths=widths, hAlign="LEFT")
    st = [("GRID", (0,0), (-1,-1), .5, colors.grey), ("FONTSIZE", (0,0), (-1,-1), 9), ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
          ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f3f4f6")])]
    if head: st += [("BACKGROUND", (0,0), (-1,0), colors.HexColor("#4f46e5")), ("TEXTCOLOR", (0,0), (-1,0), colors.white), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold")]
    t.setStyle(TableStyle(st)); return t
P = lambda s, st=B: Paragraph(s, st)
pc = lambda v: f"{v*100:.2f}%"
s = []
s += [P("Checkout A/B Test: Statistical Report", T), P("Hypothesis testing (Z-test / Chi-square) to validate conversion lift", ParagraphStyle("c", parent=B, alignment=1)), Spacer(1, 10)]
s += [P("Executive Summary", H1),
 P(f"Variant B converted at <b>{pc(R['pB'])}</b> vs Control A at <b>{pc(R['pA'])}</b>, an observed lift of <b>+{R['diff']*100:.2f} pp</b> "
   f"(+{R['rel']*100:.1f}% relative). However, the difference is <b>not statistically significant</b> "
   f"(z = {R['z']:.2f}, p = {R['p_z']:.3f} &gt; 0.05). The 95% CI for the lift "
   f"[{R['ci'][0]*100:.2f}, {R['ci'][1]*100:.2f}] pp includes zero. The test had only ~{R['power']*100:.0f}% power. "
   f"<b>Recommendation: do not declare B the winner yet. Keep Control and extend the test to about {int(R['n_req']):,} visitors per variant.</b>")]
s += [P("1. Hypotheses", H1), P("Let p<sub>A</sub> and p<sub>B</sub> be the true conversion rates of Control and Variant (Converted = Yes / all visitors)."),
 P("<b>H0:</b> p<sub>B</sub> = p<sub>A</sub> (the variant has no effect on conversion)"),
 P("<b>H1:</b> p<sub>B</sub> &ne; p<sub>A</sub> (two-sided). Significance level &alpha; = 0.05."),
 P("<b>Data:</b> checkout_ab_test_v2.csv, 1,200 unique visitors, 1-22 July 2026, no missing values or duplicates. "
   "Sample ratio check (50/50 split): p = 1.00, so assignment is balanced. Data is internally consistent (every conversion has checkout started and order value &gt; 0).")]
s += [P("2. Sample Size and Conversion Rates", H1),
 tbl([["Metric", "A (Control)", "B (Variant)"],
      ["Visitors", R["nA"], R["nB"]], ["Conversions", R["xA"], R["xB"]],
      ["Conversion rate", pc(R["pA"]), pc(R["pB"])],
      ["95% CI (Wilson)", f"[{pc(R['ciA'][0])}, {pc(R['ciA'][1])}]", f"[{pc(R['ciB'][0])}, {pc(R['ciB'][1])}]"],
      ["Checkout started", int(fun.cs[0]), int(fun.cs[1])],
      ["Checkout to purchase", pc(fun.cs_to_conv[0]), pc(fun.cs_to_conv[1])],
      ["Revenue (INR)", f"{R['revA']:,}", f"{R['revB']:,}"]], [5*cm, 5*cm, 5*cm]),
 Spacer(1, 8), Image("charts/conversion_rates.png", width=9*cm, height=6.5*cm)]
s += [PageBreak(), P("3. Hypothesis Tests", H1), P("3a. Two-sample Z-test for proportions", H2),
 P(f"Pooled p = {R['p_pool']:.4f}; SE = sqrt(p(1-p)(1/n<sub>A</sub>+1/n<sub>B</sub>)) = {R['se_pool']:.4f}; "
   f"<b>z = (p<sub>B</sub> - p<sub>A</sub>)/SE = {R['z']:.3f}</b>. Two-sided <b>p = {R['p_z']:.4f}</b>. Critical value at &alpha;=0.05 is 1.96, so we <b>fail to reject H0</b>. "
   f"(One-sided p = {R['p_z_one']:.3f}, also above 0.05.)"),
 Image("charts/z_test.png", width=11*cm, height=6.6*cm),
 P("3b. Chi-square test of independence (Variant x Converted)", H2),
 tbl([["", "Converted", "Not converted"], ["A", R["xA"], R["nA"]-R["xA"]], ["B", R["xB"], R["nB"]-R["xB"]]], [4*cm, 4*cm, 4*cm]),
 Spacer(1, 6),
 P(f"&chi;<super>2</super> = {R['chi2']:.3f}, df = 1, <b>p = {R['p_chi']:.4f}</b> (with Yates correction: &chi;<super>2</super> = {R['chi2c']:.3f}, p = {R['p_chic']:.3f}). "
   "Chi-square (without correction) equals z<super>2</super> and gives the identical p-value, confirming both tests agree: no significant association between variant and conversion.")]
s += [P("4. Confidence Interval and Effect Size", H1),
 tbl([["Measure", "Value"],
  ["Absolute lift (B - A)", f"+{R['diff']*100:.2f} pp"],
  ["95% CI for lift", f"[{R['ci'][0]*100:.2f}, {R['ci'][1]*100:.2f}] pp (includes 0)"],
  ["Relative lift", f"+{R['rel']*100:.1f}%"], ["Risk ratio", f"{R['rr']:.3f}"],
  ["Odds ratio (95% CI)", f"{R['odds']:.2f} [{R['or_ci'][0]:.2f}, {R['or_ci'][1]:.2f}]"],
  ["Cohen's h", f"{R['h']:.3f} (very small, &lt;0.2)".replace("&lt;", "<")],
  ["Phi (Cramer's V)", f"{R['phi']:.3f} (negligible)"],
  ["Achieved power", f"{R['power']*100:.0f}%"],
  ["n per variant for 80% power at observed lift", f"{int(R['n_req']):,}"]], [7*cm, 8*cm]),
 Spacer(1, 6), Image("charts/ci_lift.png", width=10*cm, height=5.7*cm)]
s += [PageBreak(), P("5. Secondary Metrics and Segments (exploratory)", H1),
 P(f"Revenue per visitor: A = INR {R['rpvA']:.2f}, B = INR {R['rpvB']:.2f} (Welch t-test p = {R['p_t']:.3f}, not significant). "
   f"Average order value among converters: A = INR {R['aovA']:.0f}, B = INR {R['aovB']:.0f}.")]
rows = [["Segment", "n A", "n B", "Rate A", "Rate B", "Diff (pp)", "p-value"]] + \
  [[f"{r.dim}: {r.segment}", r.nA, r.nB, pc(r.rateA), pc(r.rateB), f"{r['diff']*100:+.2f}", f"{r.p:.3f}"] for _, r in seg.iterrows()]
s += [Spacer(1, 6), tbl(rows, [4.5*cm, 1.5*cm, 1.5*cm, 2*cm, 2*cm, 2.2*cm, 2*cm]), Spacer(1, 6), Image("charts/segments.png", width=11*cm, height=6.1*cm),
 P("<i>Caution:</i> 7 segment tests were run, so some 'wins' can appear by chance. No segment is significant at 0.05 (Email is closest, p = 0.093); with multiple-comparison correction none would be. These are hypothesis-generating only. B is directionally better on Mobile, Tablet and Email, flat on Desktop, and worse on Organic.")]
s += [P("6. Executive Decision Memo", H1),
 tbl([["To", "Product / Growth leadership"], ["Re", "Checkout redesign: Launch Variant vs Keep Control"],
      ["Decision", "KEEP CONTROL for now; extend test (do not launch B yet)"]], [3*cm, 12*cm], head=False),
 Spacer(1, 6),
 P(f"<b>Finding.</b> B shows +{R['diff']*100:.2f} pp (+{R['rel']*100:.1f}% relative) conversion, but p = {R['p_z']:.2f} and the 95% CI [{R['ci'][0]*100:.1f}, {R['ci'][1]*100:.1f}] pp includes zero. "
   "The true effect could be a small loss or a sizeable gain; the data cannot tell them apart."),
 P(f"<b>Why not launch.</b> With 600 visitors per arm, power is ~{R['power']*100:.0f}%. A 'significant' call now would be unreliable, and the uplift could be random noise."),
 P(f"<b>Why not abandon B.</b> The direction is positive, the funnel step from checkout to purchase improved ({pc(fun.cs_to_conv[0])} to {pc(fun.cs_to_conv[1])}), and revenue per visitor is higher (INR {R['rpvA']:.1f} to {R['rpvB']:.1f}). The result is promising but inconclusive."),
 P(f"<b>Next steps.</b> (1) Continue the test to at least {int(R['n_req']):,} visitors per variant (about 14 weeks at the current traffic of ~200 per variant per week). "
   "(2) Fix the sample size in advance and do not stop early on a good-looking p-value. (3) Pre-register Mobile/Tablet and Email as follow-up segments. "
   "(4) Launch B if the extended test reaches p &lt; 0.05 with a CI above zero and no guardrail regressions."),
 P("<b>Assumptions and limits.</b> Visitors are independent and randomly assigned (balanced split confirmed); one conversion per visitor; test window was 3 weeks, so weekly seasonality is covered but not holiday effects.")]
SimpleDocTemplate("AB_Test_Report.pdf", pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=1.8*cm, bottomMargin=1.8*cm, title="Checkout A/B Test Report").build(s)
